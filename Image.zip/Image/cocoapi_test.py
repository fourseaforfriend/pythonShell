import skimage.io as io
import matplotlib.pyplot as plt
from pycocotools.coco import COCO

filePath = ''
